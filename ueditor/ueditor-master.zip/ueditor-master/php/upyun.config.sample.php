<?php
$bucketname = '';   // 服务名称
$username = '';     // 操作员账号
$password = '';     // 操作员密码
