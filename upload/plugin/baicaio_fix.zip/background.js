(function($, doc) {
	/*
	 *设定定时刷新启动时间为当前时间
	 */
	//--主页文章列表获取时间点
	var bgListTime = getDateTime(new Date());
	var bgListID = 0;
	//--白菜文章列表获取时间点
	var bgBarginTime = getDateTime(new Date());
	var bgBarginID = 0;
	//--自定义文章列表获取时间点
	var bgCusTime = getDateTime(new Date());
	var bgCusID = 0;
	//定时调用
	setInterval(function() {
		//popup.html页最近一次刷新的时间锚点
		var listPointer = JSON.parse(localStorage.getItem("listPointer_baicaio"));
		var barginPointer = JSON.parse(localStorage.getItem("barginPointer_baicaio"));
		var cusPointer = JSON.parse(localStorage.getItem("cusPointer_baicaio"));
		//重新设定定时刷新的时间锚点
		if(listPointer) {
			bgListTime = (bgListTime <= listPointer.time) ? listPointer.time : bgListTime;
			bgListID = (bgListID <= listPointer.id) ? listPointer.id : bgListID;
		} else {
			var Obj = {
				time: bgListTime,
				id: bgListID
			};
			localStorage.setItem("listPointer_baicaio", JSON.stringify(Obj));
		};

		if(barginPointer) {
			bgBarginTime = (bgBarginTime <= barginPointer.time) ? barginPointer.time : bgBarginTime;
			bgBarginID = (bgBarginID <= barginPointer.id) ? barginPointer.id : bgBarginID;
		} else {
			var Obj = {
				time: bgBarginTime,
				id: bgBarginID
			};
			localStorage.setItem("barginPointer_baicaio", JSON.stringify(Obj));
		};

		if(cusPointer) {
			bgCusTime = (bgCusTime <= cusPointer.time) ? cusPointer.time : bgCusTime;
			bgCusID = (bgCusID <= cusPointer.id) ? cusPointer.id : bgCusID;
		} else {
			var Obj = {
				time: bgCusTime,
				id: bgCusID
			};
			localStorage.setItem("cusPointer_baicaio", JSON.stringify(Obj));
		};

		var optionsStorage = JSON.parse(localStorage.getItem("options_baicaio"));
		if(!optionsStorage) { //初始化配置参数
			var options = {
				allNotify: 0,
				BarginNotify: 1,
				customizeNotify: 0,
				notifyDure: 10,
				customizeItems: ''
			}
			localStorage.setItem("options_baicaio", JSON.stringify(options));
			optionsStorage = options;
		}
		//获取列表更新
		if(parseInt(optionsStorage.allNotify) == 1) {
			//全文推送
			getList(bgListTime, bgListID, 0, "", "", function(data) {				
				if(data.length > 0) {
					bgListTime = getDateTime(new Date());//记录timepointer
					bgListID = data[0]["id"];

					for(var i = data.length - 1; i >= 0; i--) {
						//createNotify(data[i], "白菜哦网List" + data[i]["id"], "List");
						showNotification(data[i], "List");
					}
				};
			});
		} else {
			//同时push白菜及定制商品时,优先获取个性化列表
			if((parseInt(optionsStorage.customizeNotify) == 1)&&(parseInt(optionsStorage.BarginNotify) == 1)) {
				getList(bgCusTime, bgCusID, 0, "", optionsStorage.customizeItems, function(data) {
					bgCusTime = getDateTime(new Date());//记录timepointer
					if(data.length > 0) {
						bgCusID = data[0]["id"];
						for(var i = data.length - 1; i >= 0; i--) {
							//createNotify(data[i], "白菜哦网Cus" + data[i]["id"], "Cus");
							showNotification(data[i], "Cus");
						}
					};
					//已通知过的商品,不重复通知
					getCusIDs(data, function(ids) {
						//获取白菜列表更新
						if(parseInt(optionsStorage.BarginNotify) == 1) {
							getList(bgBarginTime, bgBarginID, 1, ids, "", function(data) {
								if(data.length > 0) {
									bgBarginTime = getDateTime(new Date());
									bgBarginID = data[0]["id"];
									for(var i = data.length - 1; i >= 0; i--) {
										//createNotify(data[i], "白菜哦网BargIn" + data[i]["id"], "Bargin");
										showNotification(data[i], "Bargin");
									}
								}
							});
						}
					})
				})
			}
			else if(parseInt(optionsStorage.customizeNotify) == 1)
			{//push定制商品
				getList(bgCusTime, bgCusID, 0, "", optionsStorage.customizeItems, function(data) {
					bgCusTime = getDateTime(new Date());//记录timepointer
					if(data.length > 0) {
						bgCusID = data[0]["id"];
						for(var i = data.length - 1; i >= 0; i--) {
							//createNotify(data[i], "白菜哦网Cus" + data[i]["id"], "Cus");
							showNotification(data[i], "Cus");
						}
					};					
				})
			}
			else if(parseInt(optionsStorage.BarginNotify) == 1)
			{//push白菜
				getList(bgBarginTime, bgBarginID, 1, "", "", function(data) {
					if(data.length > 0) {
						bgBarginTime = getDateTime(new Date());
						bgBarginID = data[0]["id"];
						for(var i = data.length - 1; i >= 0; i--) {
							//createNotify(data[i], "白菜哦网BargIn" + data[i]["id"], "Bargin");
							showNotification(data[i], "Bargin");
						}
					}
				});
			}
		}
	}, 30000);

	var getCusIDs = function(data, callback) {
		var ids = "";
		for(var i = data.length - 1; i >= 0; i--) {
			if(ids == "") {
				ids = data[i]["id"];
			} else {
				ids = "," + data[i]["id"];
			}
		}
		return callback(ids);
	}

	var getList = function(pTime, pId, pTab, pRemoveIDs, pItems, callback) {
		$.getJSON('http://118.178.130.114/getpostdata/GetPostsForCrx', {
			type: "down",
			time: pTime,
			id: pId,
			removeIDs: pRemoveIDs,
			items: pItems,
			tab: pTab
		}, function(data) {
			return callback(data);
		});
	};

	var createNotify = function(data, title, type) {
		var msg = "";
		if(type == "Cus") {
			msg = "[ 关注商品 ]"
		} else if(type == "Bargin") {
			msg = "[ 白菜 ]"
		};
		var buttons = [{
			title: "[ 白菜哦网 ]",
			iconUrl: chrome.runtime.getURL("/img/setting.png")
		}];
		var optionsStorage = JSON.parse(localStorage.getItem("options_baicaio"));
		var options = {
			type: "basic",
			title: data["fTitle"].replace("<span>", "").replace("</span>", ""),
			message: data["fSimDate"] + "    " + data["fMall"] + "    " + msg,
			iconUrl: data["fimg"],
			//			eventTime: 60 * optionsStorage.notifyDure,
			buttons: buttons
		};
		//chrome.notifications.create(title + data["id"], options, function() {
		chrome.notifications.create("msg_baicaio", options, function() {
			setTimeout(function() {
				chrome.notifications.clear("msg_baicaio", function() {});
			}, 1000 * optionsStorage.notifyDure);
		});
		chrome.notifications.onClicked.addListener(function() {
			chrome.tabs.create({ selected: true, url: data["fUrl"] });
			reduceBadge();
		});
		chrome.notifications.onButtonClicked.addListener(function() {
			chrome.tabs.create({ selected: true, url: "options.html" })
		});

		addBadge(); //设置角标
	}

	var showNotification = function(data, type) {
		var optionsStorage = JSON.parse(localStorage.getItem("options_baicaio"));
		var title = data["fTitle"].replace("<span>", "").replace("</span>", "");
		var msg = "";
		if(type == "Cus") {
			msg = "[ 关注商品 ]"
		} else if(type == "Bargin") {
			msg = "[ 白菜 ]"
		};
		var obj = new Object();
		obj.body = data["fSimDate"] + "    " + data["fMall"] + "    " + msg;
		obj.icon = data["fimg"];
		obj.urls = data["fUrl"];
		obj.tag = data["fUrl"];
		obj.dir = "auto";
		obj.lang = "";
		var notification = new Notification(title, obj);
		notification.onclick = function(event) {
			chrome.tabs.create({ selected: true, url: event.currentTarget.tag }, function(tab) {
				reduceBadge();
				chrome.windows.get(tab.windowId, function(win) {
					chrome.windows.update(win.id, { focused: true });
				});
			});
			this.close();
		};
		// 两秒后关闭通知
		setTimeout(function() {
			notification.close();
		}, 1000 * optionsStorage.notifyDure);
		addBadge(); //设置角标
	};

	//
	//	var createTestNotify = function() {
	//		var buttons = [{
	//			title: "[ 白菜哦网 ]",
	//			iconUrl: chrome.runtime.getURL("/img/setting.png")
	//		}];
	//
	//		var options = {
	//			type: "basic",
	//			title: "标题",
	//			message: "内容",
	//			iconUrl: "logo.jpg",
	//			eventTime: 60 * 5,
	//			buttons: buttons
	//		};
	//		chrome.notifications.create("白菜哦网List" + Math.random(), options, function() {});
	//		chrome.notifications.onClicked.addListener(function() {
	//			chrome.tabs.create({ selected: true, url: "http://www.baicaio.com" });
	//		});
	//		chrome.notifications.onButtonClicked.addListener(function(notifId, btnIdx) {
	//			chrome.tabs.create({ selected: true, url: "options.html" })
	//		});
	//	}
	//	createTestNotify();

	var addBadge = function() {
		chrome.browserAction.setBadgeBackgroundColor({ color: '#E74C3C' });
		var badge = localStorage.getItem("badge_baicaio");
		var count = 0;
		if(badge) {
			count = parseInt(badge) + 1;
		} else {
			count = 1;
		}
		chrome.browserAction.setBadgeText({ text: count.toString() });
		localStorage.setItem("badge_baicaio", count);
	}

	var reduceBadge = function() {
		var badge = localStorage.getItem("badge_baicaio");
		if(badge) {
			if(parseInt(badge) > 1) {
				chrome.browserAction.setBadgeBackgroundColor({ color: '#E74C3C' });
				var count = parseInt(badge) - 1;
				chrome.browserAction.setBadgeText({ text: count.toString() });
				localStorage.setItem("badge_baicaio", count);
			} else {
				clearBadge();
			}
		}
	}

	var clearBadge = function() {
		chrome.browserAction.setBadgeText({ text: "" });
		localStorage.setItem("badge_baicaio", 0);
	}

}(mui, document));