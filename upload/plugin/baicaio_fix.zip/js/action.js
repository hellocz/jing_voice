var liModel =
	'<div class="media-img">' +
	'	<img data-url="@url@" src="@img@" class="data-url"/>' +
	'</div>' +
	'<div class="media-content">' +
	'	<div class="media-content-title data-url" data-url="@url@">' +
	'		@title@' +
	'	</div>' +
	'	<div class="media-content-footer">' +
	'		<span class="media-content-footer-left">' +
	'		@time@ | @mall@' +
	'		</span>' +
	'		<span class="media-content-footer-right">' +
	'       	<button data-url="@mall_url@" type="button" class="mui-btn mui-btn-blue mui-btn-outlined data-url">直达链接</button> ' +
	'		</span>' +
	'	</div>' +
	'</div>';
var time = '1970-01-01 00:00:00';
var id = 0;
var lastTime = '1970-01-01 00:00:00';
var lastId = 0;
var tab = 0;

var cusFlag = 0;

/*
 *设定定时刷新启动时间为当前时间
 */
//--主页文章列表获取时间点
var bgLoopTime = getDateTime(new Date());
var bgLoopID = 0;

(function($, doc) {
	var arcList = doc.getElementById("arcList");
	var divBodyFooter = doc.getElementById('divBodyFooter');
	var arcHeader = doc.getElementById("arcHeader");
	var arcSpin = doc.getElementById("arcSpin");
	var divBodyFooterAddMore = doc.getElementById("divBodyFooterAddMore");
	var bodyFooterToTop = doc.getElementById("bodyFooterToTop");
	var spanFooterToTop = doc.getElementById("spanFooterToTop");

	var optionsStorage = JSON.parse(localStorage.getItem("options_baicaio"));
	if(!optionsStorage) { //初始化配置参数
		var options = {
			allNotify: 0,
			BarginNotify: 1,
			customizeNotify: 0,
			notifyDure: 10,
			customizeItems: ''
		}
		localStorage.setItem("options_baicaio", JSON.stringify(options));
		optionsStorage = options;
	};

	/*
	 * 初始化获取数据
	 */
	var getList = function(pType, pTime, pId, callback) {
		var items = "";
		if(cusFlag == 1) {
			var itemsOption = optionsStorage.customizeItems;
			items = (itemsOption == "") ? "1=2" : itemsOption;
		}
		$.getJSON('http://118.178.130.114/getpostdata/GetPostsForCrx', {
			type: pType,
			time: pTime,
			id: pId,
			removeIDs: "",
			items: items,
			tab: tab
		}, function(data) {
			if(data.length > 0) {
				var fragment = doc.createDocumentFragment();
				var li;
				if(pType == "down") {
					//初次加载时,记录末条文章的id及时间值
					if(id == 0) {
						lastTime = data[data.length - 1]["fDate"].replace("T", " ");
						lastId = data[data.length - 1]["id"];
					}
					//记录本次更新时间及最新文章id
					time = getDateTime(new Date());
					id = data[0]["id"];
					if(tab == 0) { //首页清单,最新一次获取锚点
						var lastObj = {
							time: time,
							id: id
						};
						localStorage.setItem("listPointer_baicaio", JSON.stringify(lastObj));
					} else if(tab == 1) { //白菜清单,最新一次获取锚点
						var barginObj = {
							time: time,
							id: id
						}
						localStorage.setItem("barginPointer_baicaio", JSON.stringify(barginObj));
					}

					for(var i = data.length - 1; i >= 0; i--) {
						li = doc.createElement("li");
						li.className = "media";
						li.setAttribute('data-time', data[i]["fDate"].replace("T", " "));
						li.setAttribute('data-id', data[i]["id"]);
						li.innerHTML = liModel.replace('@img@', data[i]["fimg"] + '?version=' + Math.random() * 1000)
							.replace('@title@', data[i]["fTitle"])
							.replace('@url@', data[i]["fUrl"])
							.replace('@url@', data[i]["fUrl"])
							.replace('@mall_url@', data[i]["fMall_url"])
							.replace('@time@', data[i]["fSimDate"])
							.replace('@mall@', data[i]["fMall"]);
						fragment.insertBefore(li, fragment.firstChild);
					};
					arcList.insertBefore(fragment, arcList.firstChild);
				} else {
					//记录末条文章的id及时间值
					lastTime = data[data.length - 1]["fDate"].replace("T", " ");
					lastId = data[data.length - 1]["id"];
					//上啦,加载更多时,追加文章
					for(var i = 0; i < data.length; i++) {
						li = doc.createElement("li");
						li.className = "media";
						li.setAttribute('data-time', data[i]["fDate"].replace("T", " "));
						li.setAttribute('data-id', data[i]["id"]);
						li.innerHTML = liModel.replace('@img@', data[i]["fimg"] + '?version=' + Math.random() * 1000)
							.replace('@title@', data[i]["fTitle"])
							.replace('@url@', data[i]["fUrl"])
							.replace('@url@', data[i]["fUrl"])
							.replace('@mall_url@', data[i]["fMall_url"])
							.replace('@time@', data[i]["fSimDate"])
							.replace('@mall@', data[i]["fMall"]);
						fragment.appendChild(li);
					};
					arcList.appendChild(fragment);
				};
				divBodyFooter.classList.add("mui-hidden");
				divBodyFooterAddMore.classList.remove("mui-hidden");
				bodyFooterToTop.classList.remove("mui-hidden");
			} else {
				divBodyFooterAddMore.classList.add("mui-hidden");
				bodyFooterToTop.classList.add("mui-hidden");
			}

			arcSpin.classList.add("mui-hidden");
			return callback("ok");
		});
	};

	/*
	 *初次加载时,获取文章列表
	 * */
	getList('down', time, id, function(data) {});
	/*
	 *下拉刷新			 
	 */
	//	function pulldownRefresh() {
	//		$.later(function() {
	//			getList('down', time, id, function(data) {
	//				mui('#arcContent').pullRefresh().endPulldownToRefresh();
	//			});
	//		}, 100)
	//	}
	/*
	 *上拉加载 
	 */
	//	function pullupRefresh() {
	//		$.later(function() {
	//			getList('up', lastTime, lastId, function(data) {
	//				mui('#arcContent').pullRefresh().endPullupToRefresh();
	//			});
	//		}, 500);
	//	}
	/*
	 *点击加载按钮,获取更多
	 * */
	var btnMore = doc.getElementById('btnGetMore');
	btnMore.addEventListener('tap', function() {
		btnMore.innerHTML = "加载中";
		getList('up', lastTime, lastId, function(data) {
			btnMore.innerHTML = "更多";
		});
	});
	/*
	 *获取白菜按钮
	 * */
	var btnBargin = doc.getElementById("btnBargin");
	btnBargin.addEventListener('tap', function() {
		initParams();
		btnBargin.classList.add("active");
		btnAll.classList.remove("active");
		btnCus.classList.remove("active");
		tab = 1;
		cusFlag = 0;

		doc.getElementById("arcList").innerHTML = "";

		getList('down', lastTime, lastId, function(data) {

		});
	});

	/*
	 *获取最新文章
	 * */
	var btnAll = doc.getElementById("btnAll");
	btnAll.addEventListener('tap', function() {
		initParams();
		btnBargin.classList.remove("active");
		btnAll.classList.add("active");
		btnCus.classList.remove("active");
		tab = 0;
		cusFlag = 0;

		doc.getElementById("arcList").innerHTML = "";

		getList('down', lastTime, lastId, function(data) {

		});

	});
	/*
	 *关注
	 * */
	var btnCus = doc.getElementById("btnCus");
	btnCus.addEventListener('tap', function() {
		initParams();
		btnBargin.classList.remove("active");
		btnAll.classList.remove("active");
		btnCus.classList.add("active");
		tab = 0;
		cusFlag = 1;

		doc.getElementById("arcList").innerHTML = "";

		getList('down', lastTime, lastId, function(data) {

		});

	});

	var initParams = function() {
		time = '1970-01-01 00:00:00';
		id = 0;
		lastTime = '1970-01-01 00:00:00';
		lastId = 0;
		arcSpin.classList.remove("mui-hidden");
	}

	var showOptions = doc.getElementById("showOptions");
	showOptions.addEventListener('tap', function() {
		chrome.tabs.create({
			selected: true,
			url: "options.html"
		})
	});
	//打开Popup页面时,清空角标
	var clearBadge = function() {
		chrome.browserAction.setBadgeText({
			text: ""
		});
		localStorage.setItem("badge_baicaio", 0);
	};
	clearBadge();
	/*
	 *获取文章更新信息
	 * */
	var getNewList = function(pTime, pId, pTab, pRemoveIDs, pItems, callback) {
		$.getJSON('http://118.178.130.114/getpostdata/GetPostsForCrx', {
			type: "down",
			time: pTime,
			id: pId,
			removeIDs: pRemoveIDs,
			items: pItems,
			tab: pTab
		}, function(data) {
			return callback(data);
		});
	};
	//检查新文章
	setInterval(function() {
		//设定获取文章更新的时间锚点
		var loopPointer = JSON.parse(localStorage.getItem("loopPointer_baicaio"));
		if(loopPointer) {
			bgLoopTime = (bgLoopTime <= loopPointer.time) ? loopPointer.time : bgLoopTime;
			bgLoopID = (bgLoopID <= loopPointer.id) ? loopPointer.id : bgLoopID;
		} else {
			var Obj = {
				time: bgLoopTime,
				id: bgLoopID
			};
			localStorage.setItem("loopPointer_baicaio", JSON.stringify(Obj));
		};

		/*
		 *定时检查文章更新
		 * */
		getNewList(bgLoopTime, bgLoopID, 0, "", "", function(data) {
			if(data.length > 0) {
				bgLoopTime = getDateTime(new Date());
				bgLoopID = data[0]["id"];

				for(var i = data.length - 1; i >= 0; i--) {
					arcHeader.innerHTML = "新白菜来啦...点我点我";
					arcHeader.classList.remove("mui-hidden");
					spanFooterToTop.classList.add("breathe");
				}
			}
		});
	}, 60000);

	//点击新文章提示,加载新文章
	arcHeader.addEventListener('tap', function() {
		arcHeader.classList.add("mui-hidden");
		$.trigger(btnAll, 'tap');
		spanFooterToTop.classList.remove("breathe");
	});

	//获取滚动条当前的位置 
	function getScrollTop() {
		var scrollTop = 0;
		if(document.documentElement && document.documentElement.scrollTop) {
			scrollTop = document.documentElement.scrollTop;
		} else if(document.body) {
			scrollTop = document.body.scrollTop;
		}
		return scrollTop;
	}

	//获取当前可是范围的高度 
	function getClientHeight() {
		var clientHeight = 0;
		if(document.body.clientHeight && document.documentElement.clientHeight) {
			clientHeight = Math.min(document.body.clientHeight, document.documentElement.clientHeight);
		} else {
			clientHeight = Math.max(document.body.clientHeight, document.documentElement.clientHeight);
		}
		return clientHeight;
	}

	//获取文档完整的高度 
	function getScrollHeight() {
		return Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
	}

	window.addEventListener('scroll', function() {
		if(getScrollTop() + getClientHeight() == getScrollHeight()) {
			divBodyFooter.classList.remove("mui-hidden");
			divBodyFooterAddMore.classList.add("mui-hidden");
			getList('up', lastTime, lastId, function(data) {
				divBodyFooter.classList.add("mui-hidden");
			});
		}
	})

	bodyFooterToTop.addEventListener('tap', function() {
		window.scrollTo(0, 0);
		spanFooterToTop.classList.remove("breathe")
	});

	$('#arcList').on('tap', '.data-url', function(e) {
		var url = this.getAttribute('data-url');
		if(url) {
			chrome.tabs.create({
				selected: false,
				url: url
			})
		}
	});

}(mui, document));