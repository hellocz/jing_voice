function getDateTime(date) {

	var year = date.getFullYear();
	var month = date.getMonth() + 1;
	var Date = date.getDate();
	var hour = date.getHours();
	var min = date.getMinutes(); //获取当前分钟数(0-59)  
	var sec = date.getSeconds(); //获取当前秒数(0-59)  

	if (month >= 1 && month <= 9) {
		month = "0" + month;
	}
	if (Date >= 0 && Date <= 9) {
		Date = "0" + Date;
	}
	if (hour >= 0 && hour <= 9) {
		hour = "0" + hour;
	}
	if (min >= 0 && min <= 9) {
		min = "0" + min;
	}
	if (sec >= 0 && sec <= 9) {
		sec = "0" + sec;
	}

	var datetime = year + '-' + month + '-' + Date + ' ' + hour + ':' + min + ':' + sec;
	
	return datetime;
}