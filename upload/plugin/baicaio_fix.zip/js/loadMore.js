
$('#divBodyFooter').waypoint(function(){
		$('#divBodyFooter').removeClass("mui-hidden");
		console.log("123");
	},{
		offset:'120'
	});