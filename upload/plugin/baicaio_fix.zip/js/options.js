var initControler = function() {
	var optionsStorage = JSON.parse(localStorage.getItem("options_baicaio"));
	if(optionsStorage){
		if(parseInt(optionsStorage.allNotify) == 1) {
			swAllNotify.classList.add("mui-active");
			swBarginNotify.parentNode.parentNode.classList.add("mui-hidden");
			swCustomizeNotify.parentNode.parentNode.classList.add("mui-hidden");
		};
		if(parseInt(optionsStorage.BarginNotify) == 1) {
			swBarginNotify.classList.add("mui-active");
		};
		if(parseInt(optionsStorage.customizeNotify) == 1) {
			swCustomizeNotify.classList.add("mui-active");
		};
		
		ipNotifyDure.value = optionsStorage.notifyDure;//提醒窗体停留时间
		spNotifyDure.innerHTML = optionsStorage.notifyDure;
		ipCustomizeItems.value = optionsStorage.customizeItems;//定制关注商品			
	}else{
		//初始化配置参数 options_baicaio
		var options = {
			allNotify :0,
			BarginNotify :1,
			customizeNotify :0,
			notifyDure : 10,
			customizeItems:''
		}
		localStorage.setItem("options_baicaio",JSON.stringify(options));
		swBarginNotify.classList.add("mui-active");
		ipNotifyDure.value = 10;//提醒窗体停留时间
		spNotifyDure.innerHTML = 10;
	}
};

(function($, doc) {
	//根据用户设置信息,初始化控件显示
	initControler();
	//全文
	var swAllNotify = doc.getElementById("swAllNotify");
	swAllNotify.addEventListener('toggle', function(e) {
		var options = JSON.parse(localStorage.getItem("options_baicaio"));
		options.allNotify = e.detail.isActive ? 1 : 0;
		//选择全文推送时,关闭白菜/个性化 推送选项
		if(e.detail.isActive){
			options.BarginNotify = 0;
			options.customizeNotify = 0;
			if(swBarginNotify.classList.contains("mui-active")){
				$('#swBarginNotify').switch().toggle();
			};
			if(swCustomizeNotify.classList.contains("mui-active")){
				$('#swCustomizeNotify').switch().toggle();
			};
			swBarginNotify.parentNode.parentNode.classList.add("mui-hidden");
			swCustomizeNotify.parentNode.parentNode.classList.add("mui-hidden");			
		}else{
			swBarginNotify.parentNode.parentNode.classList.remove("mui-hidden");
			swCustomizeNotify.parentNode.parentNode.classList.remove("mui-hidden");
		}
		localStorage.setItem("options_baicaio", JSON.stringify(options));
		//重新设置文章过滤时间锚点
		var listPointer = JSON.parse(localStorage.getItem("listPointer_baicaio"));
		if(listPointer){
			var Obj = {
				time: getDateTime(new Date()),
				id: 0
			};
			localStorage.setItem("listPointer_baicaio", JSON.stringify(Obj));
		}
	});
	//白菜
	var swBarginNotify = doc.getElementById("swBarginNotify");
	swBarginNotify.addEventListener('toggle', function(e) {
		var options = JSON.parse(localStorage.getItem("options_baicaio"));
		options.BarginNotify = e.detail.isActive ? 1 : 0;
		localStorage.setItem("options_baicaio", JSON.stringify(options));
		//重新设置文章过滤时间锚点
		var barginPointer = JSON.parse(localStorage.getItem("barginPointer_baicaio"));
		if(barginPointer){
			var Obj = {
				time: getDateTime(new Date()),
				id: 0
			};
			localStorage.setItem("barginPointer_baicaio", JSON.stringify(Obj));
		}
	});
	//个性化
	var swCustomizeNotify = doc.getElementById("swCustomizeNotify");
	swCustomizeNotify.addEventListener('toggle', function(e) {
		var options = JSON.parse(localStorage.getItem("options_baicaio"));
		options.customizeNotify = e.detail.isActive ? 1 : 0;		
		localStorage.setItem("options_baicaio", JSON.stringify(options));
		//重新设置文章过滤时间锚点
		var cusPointer = JSON.parse(localStorage.getItem("cusPointer_baicaio"));
		if(cusPointer){
			var Obj = {
				time: getDateTime(new Date()),
				id: 0
			};
			localStorage.setItem("cusPointer_baicaio", JSON.stringify(Obj));
		}
	});
	//个性化关注商品
	var ipCustomizeItems = doc.getElementById("ipCustomizeItems");
	ipCustomizeItems.addEventListener('input',function(e){
		var options = JSON.parse(localStorage.getItem("options_baicaio"));
		options.customizeItems = this.value;
		localStorage.setItem("options_baicaio", JSON.stringify(options));
		//重新设置文章过滤时间锚点
		var cusPointer = JSON.parse(localStorage.getItem("cusPointer_baicaio"));
		if(cusPointer){
			var Obj = {
				time: getDateTime(new Date()),
				id: 0
			};
			localStorage.setItem("cusPointer_baicaio", JSON.stringify(Obj));
		}
	});
	//弹窗持续时间
	var ipNotifyDure = doc.getElementById("ipNotifyDure");
	var spNotifyDure = doc.getElementById("spNotifyDure");
	ipNotifyDure.addEventListener('input',function(){
		var options = JSON.parse(localStorage.getItem("options_baicaio"));
		options.notifyDure = this.value;
		spNotifyDure.innerHTML = this.value;
		localStorage.setItem("options_baicaio", JSON.stringify(options));
	})
	//显示自定义商品提示信息
	var showTip = doc.getElementById("showTip");
	showTip.addEventListener("tap",function(){
		doc.getElementById("hint").classList.remove("mui-hidden");
	});

}(mui, document))